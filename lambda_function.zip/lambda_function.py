import boto3
import csv
import os
import io

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# Read env variables (set by Terraform)
TABLE_NAME = os.environ['DYNAMODB_TABLE']

def lambda_handler(event, context):
    try:
        # 1. Get the bucket name and file key from the event trigger
        record = event['Records'][0]
        bucket_name = record['s3']['bucket']['name']
        file_key = record['s3']['object']['key']
        
        print(f"📂 Trigger received for: {file_key} in {bucket_name}")

        # 2. Download the CSV file from S3 into memory
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        file_content = response['Body'].read().decode('utf-8')
        
        # 3. Parse CSV data
        # We use io.StringIO to treat the string like a file
        csv_file = io.StringIO(file_content)
        reader = csv.DictReader(csv_file)
        
        table = dynamodb.Table(TABLE_NAME)
        
        # 4. Write to DynamoDB
        # Extract user_id from the filename logic or folder structure
        # Expected format: uploads/USER_ID/filename.csv
        try:
            user_id = file_key.split('/')[1] 
        except:
            user_id = "unknown_user"

        with table.batch_writer() as batch:
            for row in reader:
                metric_name = row['Metric']
                # Create unique ID using file_key to avoid duplicates
                record_id = f"{metric_name}_{file_key}"
                
                item = {
                    'user_id': user_id,
                    'record_id': record_id,
                    'metric': metric_name,
                    'value': row['Value'],
                    'unit': row['Unit'],
                    'range_low': row['Range_Low'],
                    'range_high': row['Range_High'],
                    'source_file': file_key
                }
                
                batch.put_item(Item=item)
                print(f"   -> Saved: {metric_name}")

        return {"statusCode": 200, "body": "Success"}

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        raise e